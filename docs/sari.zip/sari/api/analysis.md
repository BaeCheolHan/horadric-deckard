# 🧙‍♂️ Sari (사리) 분석 보고서

## 개요
**사리(Sari)**는 AI 에이전트가 복잡한 코드베이스를 빠르고 정확하게 이해할 수 있도록 돕는 로컬 인덱싱 및 검색 도구입니다. MCP(Model Context Protocol)를 통해 다양한 AI 도구(Codex, Claude, Cursor 등)와 연동됩니다.

## 주요 구성 요소

### 1. 데몬 (Daemon)
- **위치**: `app/main.py`, `app/indexer.py`
- **역할**: 코드베이스 스캔, 기호(Symbol) 추출, 파일 변경 감지 및 DB 업데이트.
- **특징**: 백그라운드에서 상주하며 HTTP 서버를 통해 인덱싱 정보를 제공합니다.

### 2. 데이터베이스 (Database)
- **위치**: `app/db.py`
- **기술**: SQLite + FTS5 (Full-Text Search).
- **저장 정보**: 파일 메타데이터, 기호(클래스, 함수 등), 기호 간 관계(호출, 상속), 코드 본문.

### 3. 파서 (Parsers)
- **위치**: `app/indexer.py`
- **Python**: `ast` 모듈을 사용하여 정확한 구문 분석 수행.
- **기타 언어**: Java, Kotlin, Go, C++, JS/TS 등을 위해 정규표현식 기반의 `GenericRegexParser` 사용.
- **보안**: 민감 정보(API Key, Password 등) 자동 마스킹(Redaction) 기능 내장.

### 4. MCP 서버 및 도구
- **위치**: `mcp/`, `mcp/tools/`
- **역할**: AI 에이전트가 호출할 수 있는 표준화된 도구 인터페이스 제공.
- **제공 도구**:
    - `search`: 코드 및 기호 검색.
    - `list_files`: 파일 목록 조회.
    - `read_symbol`: 특정 기호의 코드 본문 읽기.
    - `get_callers`: 특정 함수를 호출하는 곳 찾기.
    - `get_implementations`: 인터페이스 구현체 찾기.

## 기술 스택
- **언어**: Python 3.9+ (의존성 최소화)
- **저장소**: SQLite
- **프로토콜**: MCP, HTTP

## 프로젝트 구조
- `app/`: 핵심 로직 (인덱서, 워처, DB).
- `mcp/`: MCP 서버 구현 및 도구 정의.
- `config/`: 설정 관련 코드.
- `scripts/`: 설치 및 운영 스크립트.
- `tests/`: 테스트 코드.

## 워크플로우
1. **Init**: `bootstrap.sh init`으로 프로젝트 루트 설정 및 초기 인덱싱 시작.
2. **Daemon**: 인덱서가 파일을 읽어 DB에 저장하고, 워처가 변경 사항을 실시간 반영.
3. **MCP Query**: AI 에이전트가 MCP Proxy를 통해 데몬에 질의.
4. **Response**: 데몬이 DB에서 최적의 결과를 찾아 AI에게 전달.
