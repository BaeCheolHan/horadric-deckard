from .version import __version__

__all__ = ["main", "__version__"]
