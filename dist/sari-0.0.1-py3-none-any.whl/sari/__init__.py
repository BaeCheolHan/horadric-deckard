from deckard.version import __version__
